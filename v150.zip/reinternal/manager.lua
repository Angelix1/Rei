	-- Initialize core tables
	ModManager.mods = ModManager.mods or {}
	ModManager.routing = ModManager.routing or {}
	ModManager.category = ModManager.category or {}
	ModManager.funcOverride = ModManager.funcOverride or {}
	ModManager.funcroute = ModManager.funcroute or {}
	ModManager.funccat = ModManager.funccat or {}
	ModManager.loadedMods = ModManager.loadedMods or {}


	ModManager.debug = {
	    list = function()
	        local output = {}
	        for category, items in pairs(ModManager.mods) do
	            table.insert(output, string.format("%s (%d items)", category, #items))
	        end
	        ModManager.showToast("Mod Categories:\n"..table.concat(output, "\n"))
	    end,
	    find = function(id)
	        for category, items in pairs(ModManager.mods) do
	            for _, item in ipairs(items) do
	                if item.id == id then
	                    ModManager.showToast(string.format(
	                        "'%s' found in %s\nMod: %s",
	                        id, category, item.modName
	                    ))
	                    return
	                end
	            end
	        end
	        ModManager.showToast("ID '"..id.."' not found")
	    end
	}

	ModManager.resolutionPatterns = {
	    "^strings%.",
	    "^modloc%.",
	    -- Add more patterns here as needed
	}

	-- =========== General Functions
	function ModManager.safeRequire(path)  
	    local ok, result = pcall(require, path)  -- Wrap vanilla require
	    if not ok then
	        logToFile("[Mod Manager] Optional module not found: " .. path)
	        return nil
	    end
	    return result
	end

	function ModManager.clearLog(targetfile)
	    local logPath = system.pathForFile(targetfile, system.DocumentsDirectory)
	    local wipeFile = io.open(logPath, "w")
	    if wipeFile then
	        wipeFile:close()
	        return true  -- Return success status
	    end
	    return false
	end

	-- added for extending the resolution table
	function ModManager.addResolutionPatterns(...)
	    for _, pattern in ipairs({...}) do
	        table.insert(ModManager.resolutionPatterns, pattern)
	    end
	end

	-- Updated in v1.1.2
	function ModManager.deepCopyWithResolution(t, s)
	    for k, v in pairs(s) do
	        if type(v) == "string" then
	            local shouldResolve = false
	            -- Check against all configured patterns
	            for _, pattern in ipairs(ModManager.resolutionPatterns) do
	                if v:match(pattern) then
	                    shouldResolve = true
	                    break
	                end
	            end
	            
	            if shouldResolve then
	                t[k] = ModManager.resolveGlobalPath(v) or v
	            else
	                t[k] = v
	            end
	        elseif type(v) == "table" then 
	            t[k] = ModManager.deepCopyWithResolution({}, v)
	        else
	            t[k] = v
	        end
	    end
	    return t
	end

	function ModManager.resolveGlobalPath(path)
	    local func, err = loadstring("return " .. path)
	    if not func then
	        logToFile("[ModManager] Load error: " .. tostring(err))
	        return path
	    end

	    local ok, result = pcall(func)
	    if ok then
	        return result
	    else
	        logToFile("[ModManager] Resolve failed: " .. path .. " | " .. tostring(result))
	        return path
	    end
	end

	function ModManager.safeEval(path, noReturn)
	    local f, loadErr 
	    if noReturn then
	        f, loadErr = loadstring(path)
	    else
	        f, loadErr = loadstring("return " .. path)
	    end
	    if not f then
	        logToFile("[ModManager] safeEval load error: " .. tostring(loadErr))
	        return false, loadErr
	    end

	    local ok, result = pcall(f)
	    if not ok then
	        logToFile("[ModManager] safeEval runtime error: " .. tostring(result))
	        return false, result
	    end

	    return true, result
	end

	function ModManager.replaceSlashes(input_str, replacement)
	    replacement = replacement or ""  -- Default: remove slashes
	    return string.gsub(input_str, "/", replacement)
	end

	function ModManager.showToast(message, title, opt)
	    if not message then
	    	return ModManager.showToast("ModManager.showToast(message[string], title[string], opt[table])")
	    end
	    if type(opt) ~= "table" then
	        opt = { "OK" }
	    end
	    
	    title = title or "Info"
	    
	    -- Attempt native toast first
	    if native.showAlert then
	        native.showAlert(title, message, opt)
	    else
	    	main.interface:open({
				id = "message",
				title = "Toast",
				text = message
			})
	    end
	    
	    logToFile("[TOAST] "..message)
	end

	function ModManager.exportModList()
	    local path = system.pathForFile("modlist.txt", system.DocumentsDirectory)
	    local file = io.open(path, "w")
	    
	    if not file then
	        ModManager.showToast("Failed to save modlist!")
	        return
	    end
	    
	    file:write("=== ACTIVE MODS ===\n")
	    for _, items in pairs(ModManager.loadedMods) do
	        file:write(string.format("\n[%s]\n", items.name))
	        
	    end
	    
	    file:close()
	    ModManager.showToast("Modlist saved to documents")
	    logToFile("[EXPORT] Modlist saved to "..path)
	end

	-- Added: 1.1.0
	function ModManager.isVersionSufficient(requiredVersion, currentVersion)
	    -- Return true if no required version is specified
	    if not requiredVersion or requiredVersion == "" then return true end
	    
	    -- Return false if current version doesn't exist
	    if not currentVersion or currentVersion == "" then return false end

	    -- Split version strings into numeric components
	    local function splitVersion(version)
	        local parts = {}
	        for part in string.gmatch(version, "%d+") do
	            table.insert(parts, tonumber(part))
	        end
	        return parts
	    end

	    local reqParts = splitVersion(requiredVersion)
	    local curParts = splitVersion(currentVersion)

	    -- Compare each component
	    for i = 1, math.max(#reqParts, #curParts) do
	        local req = reqParts[i] or 0
	        local cur = curParts[i] or 0

	        if req > cur then
	            return false  -- Current version is insufficient
	        elseif req < cur then
	            return true   -- Current version exceeds requirement
	        end
	        -- If equal, skip
	    end

	    return true  -- Versions are exactly equal
	end


	-- =========== Modder-friendly API
	function ModManager.regFuncOverride(category, funcData, label)
	    label = label or "unnamed"
	    
	    if type(funcData) ~= "table" then
	        logToFile("[ModManager] ERROR: funcData must be a table ("..label..")")
	        return
	    end
	    
	    -- Check if category exists
	    if not ModManager.funccat[category] then
	        local available = {}
	        for _, cat in pairs(ModManager.funccat) do
	            table.insert(available, cat)
	        end
	        table.sort(available)
	        
	        logToFile(string.format(
	            "[ModManager] ERROR (%s): Invalid category '%s'\n"..
	            "Available: %s\n"..
	            "Did you mean? Or call ModManager.extendFuncRoute('your.path', '%s')",
	            label, category, table.concat(available, ", "), category
	        ))
	        return
	    end

	    -- Initialize mods table for this category if needed
	    if not ModManager.funcOverride[category] then
	        ModManager.funcOverride[category] = {}
	    end
	    
	    for funcName, newFunc in pairs(funcData) do
	        ModManager.funcOverride[category][funcName] = newFunc
	        logToFile(string.format(
	            "[ModManager] Registered function '%s' in category '%s' (%s)",
	            funcName, category, label
	        ))
	    end
	end

	function ModManager.register(category, data, label) -- "drink", {} , "MOD Kewl"
	    -- Input validation
	    label = label or "unnamed_mod"

	    if type(data) ~= "table" then
	        logToFile("[ModManager] ERROR: Data must be a table ("..label..")")
	        return
	    end
	    
	    -- Check if category exists
	    if not ModManager.category[category] then
	        local available = {}
	        for _, cat in pairs(ModManager.category) do
	            table.insert(available, cat)
	        end
	        table.sort(available)
	        
	        logToFile(string.format(
	            "[ModManager] ERROR (%s): Invalid category '%s'\n"..
	            "Available: %s\n"..
	            "Did you mean? Or call ModManager.extendRoute('your.path', '%s')",
	            label, category, table.concat(available, ", "), category
	        ))
	        return
	    end

	    -- Initialize mods table for this category if needed
	    if not ModManager.mods[category] then
	        ModManager.mods[category] = {}
	    end
	    
	    -- Filter and insert valid data
	    local filteredData = {}
	    for _, item in pairs(data) do
	        if item and (item.id or item.name) then
	            table.insert(filteredData, item)
	        end
	    end
	  
	    for _, cleanData in pairs(filteredData) do
		    -- Conflict check
	    	local key = cleanData.id or cleanData.name
	        if key then
	            if conflictTracker[key] then
	                -- ModManager.showToast(string.format("CONFLICT: %s overwrites %s", label, key))
	                logToFile(string.format(
	                    "[CONFLICT] %s -> %s (previously by %s)",
	                    label, key, conflictTracker[key]
	                ))
	            end
	            conflictTracker[key] = label
	        end
	        table.insert(ModManager.mods[category], cleanData)
	    end
	    
	    logToFile(string.format(
	        "[ModManager] Registered %d/%s entry to '%s' (Mod Name: %s)",
	        #filteredData,
	        tostring(#data) or "n",
	        category,
	        label
	    ))
	end


	-- =========== Extend the Routing
	function ModManager.extendFuncRoute(path, category)
	    if type(path) == "string" and type(category) == "string" then
	        ModManager.funcroute[path] = category
	        ModManager.funccat[category] = path
	        logToFile("[ModManager] Mapped '"..path.."' → function category '"..category.."' | '".. category .."' → to path'"..path.."'")
	    else
	        logToFile("[ModManager.extendFuncRoute] WARNING: Invalid route extension - both arguments must be strings")
	    end
	end

	function ModManager.extendRoute(path, category) -- "lib.items.drink", "drink"
	    if type(path) == "string" and type(category) == "string" then
	        -- Add to path→category mapping
	        ModManager.routing[path] = category
	        
	        -- Check if category exist
	        if not ModManager.category then
	        	ModManager.category = {}
	        end

	        -- Add to category→paths mapping
	        ModManager.category[category] = path
	        
	        logToFile("[ModManager] Added route: "..path.." → "..category)
	        logToFile("[ModManager] Added category: "..category.." → "..path)
	    else
	        logToFile("[ModManager.extendRoute] WARNING: Invalid route extension - both arguments must be strings")
	    end
	end

	-- init mods routing for category
	function ModManager.catroute()
	    if ModManager.category then
	        ModManager.category = {}
	    end
	    
	    for path, category in pairs(ModManager.routing) do
	        ModManager.category[category] = path
	    end

	    logToFile("[ModManager] categories has been setup")
	end
