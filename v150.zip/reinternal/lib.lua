	-- ================================== Function Hijacks

	-- Updated in v150
	function require(path)
	    -- Splash screen hook (unchanged)
	    if path == "lib.loading._loading_master" then
	        local old = oldRequire(path)
	        local origStart = old.start
	        old.origStart = origStart
	        old.start = function(m)
	            timer.performWithDelay(2000, function()
	                timer.performWithDelay(500, showSplash)
	                old.origStart(m)
	            end)
	        end
	        return old
	    end
	    
	    -- Cache lookups
	    local funcCategory = ModManager.funcroute[path]
	    local funcOverride = funcCategory and ModManager.funcOverride[funcCategory]
	    local dataCategory = ModManager.routing[path]
	    local dataOverride = dataCategory and ModManager.mods[dataCategory]
	    
	    -- Early exit for non-modded paths
	    if not funcCategory and not dataCategory then
	        return oldRequire(path)
	    end

	    local success, original = pcall(oldRequire, path)
	    if not success then
	        logToFile("[ModManager] REQUIRE FAILED: "..path.." | Error: "..tostring(original))
	        return nil
	    end
	    
	    if type(original) == "table" then
	        local modified = table.copy({ original })[1]  -- Always copy first
	        
	        if funcOverride then
	            -- PHASE 1: Replace Whole Table
	            if funcOverride.isReplaceTable then
	                modified = funcOverride.replacement
	                logToFile("[ModManager] FULL TABLE REPLACEMENT: ".. path)        
	            -- PHASE 2: Function/Value overrides        
	            elseif funcOverride.isIndexedTable then
	                    -- check item key
	                local targetCond = funcOverride.targetKey
	                
	                for _, item in ipairs(modified) do -- loop original 
	                    local fix = item[targetCond]
	                    if fix and funcOverride[fix] then  -- Check if ID exists and has overrides
	                        for path, override in pairs(funcOverride[fix]) do -- loop mod entry
	                            local target = item
	                            local keys = {}
	                            
	                            -- Split path (e.g., "stat.damage" → {"stat", "damage"})
	                            for part in path:gmatch("[^.]+") do
	                                table.insert(keys, part)
	                            end
	            
	                            -- Navigate to target (skip if invalid path)
	                            for i = 1, #keys-1 do
	                                if type(target) ~= "table" or not target[keys[i]] then 
	                                    break 
	                                end
	                                target = target[keys[i]]
	                            end
	                            
	                            target[keys[#keys]] = override
	                            logToFile(string.format("[ModManager] Override [Index] %s.%s = %s", item.id, path, override))
	                        end
	                    end
	                end
	            elseif funcOverride.append then
	                if funcOverride.data then
	                    modified = table.js.safeMerge(modified, funcOverride.data)
	                end
	            else 
	            -- Normal Mode (Flat/dot-notation overrides)
	                for path, override in pairs(funcOverride) do
	                    local target = modified
	                    local keys = {}
	                    
	                    for part in path:gmatch("[^.]+") do
	                        table.insert(keys, part)
	                    end
	                    
	                    for i = 1, #keys-1 do
	                        if not target[keys[i]] then break end
	                        target = target[keys[i]]
	                    end
	                    
	                    if target[keys[#keys]] then
	                        target[keys[#keys]] = override
	                        logToFile(string.format("[ModManager] Override [FlatKey] %s.%s", path, path))
	                    end
	                end
	            end
	        end
	        -- PHASE 3: Data merges
	        if dataOverride then
	            modified = table.copy(modified, ModManager.deepCopyWithResolution({}, dataOverride))
	        end

	        return modified
	    else
	        -- PHASE 2: Global hijacks
	        if funcOverride then
	            for funcPath, override in pairs(funcOverride) do
	                if override.nonExport and override.func then
	                    local target = _G
	                    local parts = {}
	                    
	                    for part in funcPath:gmatch("[^.]+") do
	                        table.insert(parts, part)
	                    end
	                    
	                    for i = 1, #parts-1 do
	                        if not target[parts[i]] then break end
	                        target = target[parts[i]]
	                    end
	                    
	                    if target and target[parts[#parts]] then
	                        target[parts[#parts]] = override.func
	                        logToFile("[ModManager] Hijacked: "..funcPath)
	                    end
	                end
	            end
	        end
	        return original
	    end
	end

	display.newImage = function(...)
	    -- Handle non-string paths safely
	    local args = {...}
	    local firstArg = args[1]
	    if type(firstArg) ~= "string" then
	        return originalNewImage(...)  -- Fall back to original behavior
	    end

	    local originalPath = firstArg
	    local isModded = includes(originalPath, "modded_assets/")
	    local finalPath = originalPath

	    -- Process modded paths
	    if isModded then
	        -- Extract mod path (e.g., "modded_assets/assets/image.png")
	        local modRelativePath = originalPath:match("modded_assets/(.+)")
	        if modRelativePath then
	            finalPath = system.pathForFile("angel_mod/modlist/"..modRelativePath, system.DocumentsDirectory)
	            
	            -- LFS file check
	            local fileAttr = lfs.attributes(finalPath)
	            if not fileAttr or fileAttr.mode ~= "file" then
	                logToFile("[Image Load] MOD MISSING: "..finalPath)
	                return originalNewImage(...)  -- Fallback to original asset
	            end
	        end
	    end

	    -- Debug logging
	    if EnableDebugLog then
	    	logToFile(string.format("[Image Load] %s: %s", isModded and "MOD" or "ORIGINAL", isModded and finalPath or originalPath ))
	    end

	    -- Protected load
	    local success, image = pcall(originalNewImage, finalPath, select(2, ...))
	    if success then
	        return image
	    else
	        logToFile("[Image Load] FAILED: "..finalPath.." | "..tostring(image))
	        return originalNewImage(...)  -- Ultimate fallback
	    end
	end
	-- ==================================================================== setup files

	local filesData = sreq("reinternal.files")

	if filesData then
		-- List of Folder that needs to be created
		local folders = {
		    "angel_mod",
		    "angel_mod/modlist",
		    "angel_mod/modlist/assets",
		    "angel_mod/modlist/.example_mod",
		    "angel_mod/modlist/.example_mod/afterload",
		    "angel_mod/modlist/.example_mod/preload",
		}

		-- list of files that needs to be created
		local files = {
		    {
		        path = "reinternal/core.lua",
		        content = filesData.core
		    },
		    { 
		        path = "angel_mod/feature.lua", 
		        content = filesData.feature
		    },
		    { 
		        path = "angel_mod/loader.lua", 
		        content = filesData.loader 
		    },
		    { 
		        path = "angel_mod/menu.lua", 
		        content = filesData.menu
		    },
		    {
		        path = "angel_mod/modlist/.example_mod/afterload/damage.lua",
		        content = filesData.example_mod_afterload
		    },
		    {
		        path = "angel_mod/modlist/.example_mod/preload/item.lua",
		        content = filesData.example_mod_preload
		    },
		    {
		        path = "angel_mod/modlist/.example_mod/manifest.lua",
		        content = filesData.example_mod_manifest
		    },
		    {
		        path = "angel_mod/modlist/readme.md",
		        content = filesData.readme
		    }
		}

		setupModDirectories(folders, files)

	end

	-- ==================================================================== Things
	ModManager.clearLog("debug_log.txt")
	modMenu = require("angel_mod.menu")



	-- ==================================================================== INIT
	local core = sreq("reinternal.core")
	if core and core.init then
		core.init()
	else
		logToFile("Core Not Found")
	end
