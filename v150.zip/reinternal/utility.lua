	function setupModDirectories(folders, files)
		local basePath = system.pathForFile("", system.DocumentsDirectory)

		if not folders and not files then
			logToFile("[setupModDirectories] ❌ inputs[folders|files] nil")
			return
		end
		
		if type(folders) ~= "table" and type(files) ~= "table" then
			logToFile("[setupModDirectories] ❌ inputs[folders|files] is not a table")
			return
		end
		
		-- Create folders
		for _, folder in ipairs(folders) do
			local fullPath = basePath .. "/" .. folder
			if not lfs.attributes(fullPath) then
				local success, err = lfs.mkdir(fullPath)
				if not success then
					logToFile("[setupModDirectories] ❌ Failed to create '"..folder.."': "..tostring(err))
					return false
				end
				logToFile("[setupModDirectories] ✔ Created directory: "..folder)
			end
		end
		
		-- Create files (only if they don't exist)
		for _, file in ipairs(files) do
			local fullPath = basePath .. "/" .. file.path
			if not io.open(fullPath, "r") then
				local f = io.open(fullPath, "w")
				if f then
					f:write(file.content)
					f:close()
					logToFile("[setupModDirectories] ✔ Created file: "..file.path)
				else
					logToFile("[setupModDirectories] ❌ Failed to create file: "..file.path)
					return false
				end
			end
		end
		
		return true
	end

	function includes(s, substring)
		return string.find(s, substring, 1, true) ~= nil
	end

	function endswith(s, suffix)
		return string.sub(s, -#suffix) == suffix
	end

	function startswith(s, prefix)
		return string.sub(s, 1, #prefix) == prefix
	end

	function tableContains(tbl, item)
		for _, value in pairs(tbl) do
			if value == item then
				return true
			end
		end
		return false
	end

	function getModPath(originalPath)
		-- Check if path contains "modded_assets/"
		if not includes(originalPath, "modded_assets/") then
			return nil  -- Not a mod path
		end

		-- Extract everything after "modded_assets/"
		local modRelativePath = originalPath:match("modded_assets/(.+)")
		
		-- Rebuild full path in DocumentsDirectory
		return system.pathForFile("angel_mod/modlist/" .. modRelativePath, system.DocumentsDirectory)
	end

	function dump(tbl, maxDepth)
		if type(tbl) ~= "table" then
			return tbl
		end
		maxDepth = maxDepth or 5

		local function dumpTable(tbl, depth, maxDepth)
			if depth > maxDepth then
				return "default table: " .. tostring(tbl)
			end

			local nl = "\n"
			local eqm = "\""

			local result = "{" .. nl
			local indent = string.rep("  ", depth)


			for k, v in pairs(tbl) do
				result = result .. indent .. "[" .. tostring(k) .. "] = "

				if type(v) == "table" then
					result = result .. dumpTable(v, depth + 1, maxDepth)
				elseif type(v) == "string" then
					result = result .. eqm .. tostring(v) .. eqm
				else
					result = result .. tostring(v)
				end

				result = result .. "," .. nl
			end

			result = result .. string.rep("  ", depth - 1) .. "}"
			return result
		end

		return dumpTable(tbl, 1, maxDepth)
	end


	function wtf(filename, message)
		local path = system.pathForFile(filename .. ".txt" or "unnamed.txt", system.DocumentsDirectory)
		local file = io.open(path, "a") -- Append mode
		if file then
			if type(message) == "table" then				
				file:write("\n\n" .. tostring(dump(message)) .. "\n\n")
				io.close(file)
			else
				file:write(tostring(message) .. " \n\n")
				io.close(file)
			end
		end
	end
		
			
	--- Helper: Checks if a table is an array (sequential numeric indices starting at 1)
	--- @param t table The table to check
	--- @return boolean True if the table is an array
	function isArray(t)
	    if type(t) ~= "table" then return false end
	    local count = 0
	    for k, _ in pairs(t) do
	        if type(k) ~= "number" or k < 1 or math.floor(k) ~= k then
	            return false
	        end
	        count = count + 1
	    end
	    -- Check if indices are sequential (no gaps)
	    for i = 1, count do
	        if t[i] == nil then
	            return false
	        end
	    end
	    return true
	end

	--- Helper: Appends array items from source to destination
	--- @param dest table Destination array
	--- @param src table Source array
	function appendArray(dest, src)
	    for _, item in ipairs(src) do
	        table.insert(dest, item)
	    end
	end

	--- Deep-merges tables, recursively. Last value wins on conflicts.
	--- Arrays are concatenated instead of having indices overwritten.
	--- @param ... Tables to merge (rightmost has highest priority for non-arrays)
	--- @return Merged table
	function table.js.merge(...)
	    local result = {}
	    for i = 1, select("#", ...) do
	        local tbl = select(i, ...)
	        if type(tbl) == "table" and tbl ~= nil then
	            for k, v in pairs(tbl) do
	                if type(v) == "table" and type(result[k]) == "table" then
	                    -- Check if both are arrays
	                    if isArray(v) and isArray(result[k]) then
	                        -- Create a new array combining both
	                        local merged = {}
	                        appendArray(merged, result[k])
	                        appendArray(merged, v)
	                        result[k] = merged
	                    else
	                        result[k] = table.js.merge(result[k], v)  -- Recurse
	                    end
	                else
	                    result[k] = v  -- Overwrite (or set new key)
	                end
	            end
	        end
	    end
	    return result
	end

	--- Deep-merges tables but errors on type clashes.
	--- Arrays are concatenated instead of having indices overwritten.
	--- @param ... Tables to merge
	--- @return Merged table
	--- @error If types conflict (e.g., string vs table) for non-array values
	function table.js.safeMerge(...)
	    local result = {}
	    for i = 1, select("#", ...) do
	        local tbl = select(i, ...)
	        if type(tbl) == "table" and tbl ~= nil then
	            for k, v in pairs(tbl) do
	                if type(v) == "table" and type(result[k]) == "table" then
	                    -- Check if both are arrays
	                    if isArray(v) and isArray(result[k]) then
	                        -- Create a new array combining both
	                        local merged = {}
	                        appendArray(merged, result[k])
	                        appendArray(merged, v)
	                        result[k] = merged
	                    else
	                        result[k] = table.js.safeMerge(result[k], v)  -- Recurse
	                    end
	                elseif result[k] ~= nil and type(v) ~= type(result[k]) then
	                    error(string.format(
					        "Type clash at key '%s': expected %s, got %s",
					        k, type(result[k]), type(v)
					    ))
					    return {}
	                else
	                    result[k] = v
	                end
	            end
	        end
	    end
	    return result
	end

	--- Safely fetches nested keys using a dot-delimited path.
	--- @param tbl table The root table to traverse.
	--- @param path string The path (e.g., "item.player.data").
	--- @return any|nil The value or nil if not found.
	function table.safeGet(tbl, path)
	    if type(tbl) ~= "table" then return nil end
	    local keys = {}
	    for key in path:gmatch("([^.]+)") do  -- Split by dots
	        table.insert(keys, key)
	    end
	    for _, key in ipairs(keys) do
	        if type(tbl) ~= "table" then return nil end
	        tbl = tbl[key]
	    end
	    return tbl
	end

	-- ====== table utilities 
	function table.js.values(tbl)
	    if type(tbl) ~= "table" then return tbl end
	    local values = {}
	    for _, v in pairs(tbl) do table.insert(values, v) end
	    return values
	end

	function table.js.keys(tbl)
	    if type(tbl) ~= "table" then return tbl end
	    local keys = {}
	    for k in pairs(tbl) do table.insert(keys, k) end
	    return keys
	end

	function table.js.find(tbl, fn)
	    for k, v in pairs(tbl) do
	        if fn(v, k) then return v end
	    end
	end

	function table.js.filter(tbl, fn)
	    local result = {}
	    for k, v in pairs(tbl) do
	        if fn(v, k) then result[k] = v end
	    end
	    return result
	end

	function table.js.map(tbl, fn)
	    local result = {}
	    for k, v in pairs(tbl) do
	        result[k] = fn(v, k)
	    end
	    return result
	end

	function table.js.findIndex(tbl, predicate, usePairs)
	    local iterator = usePairs and pairs or ipairs
	    for k, v in iterator(tbl) do
	        if predicate(v, k, tbl) then
	            return usePairs and k or tonumber(k)
	        end
	    end
	    return nil
	end	
		
	function ensurePath(path)
	    local current = ""
	    for part in path:gmatch("[^/]+") do
	        current = current .. "/" .. part
	        lfs.mkdir(current)
	    end
	end

	function tableContains(tbl, item)
	    if type(tbl) ~= "table" then
	        return false
	    end
	    for _, v in pairs(tbl) do
	        if v == item then
	            return true
	        end
	    end
	    return false
	end
