	core = {}
	lfs = lfs or require("lfs")
	ModManager.version = "1.5.0"

	-- ============================================  actual code under
	function core.init()
	    EnableDebugLog = true -- false in release
	    logToFile("=============== [CORE:start] ===============")
	    modloc = {}

	    -- =============
	    ModManager.extendRoute("lib.ally.ally_command", "ally_command")
	    ModManager.extendRoute("lib.ally.ally_list", "ally")
	    ModManager.extendRoute("lib.base_npc.base_npc_list", "basenpc")
	    ModManager.extendRoute("lib.base_npc.buyer_list", "base_buyer")
	    ModManager.extendRoute("lib.base_npc.trader_list", "base_trader")
	    ModManager.extendRoute("lib.base_npc.workshop_list", "base_workshop")
	    ModManager.extendRoute("lib.base_npc.train_list", "base_train")
	    ModManager.extendRoute("lib.base_npc.product_list", "base_product")
	    ModManager.extendRoute("lib.base_npc.product_sell_list", "base_product_sell")
	    ModManager.extendRoute("lib.base_npc.product_craft_list", "base_product_craft")
	    ModManager.extendRoute("lib.base_npc.product_repair_list", "base_product_repair")
	    ModManager.extendRoute("lib.battle.obj_list.battle_map_list", "battle_map")
	    ModManager.extendRoute("lib.battle.obj_list.battle_map_decor_list", "battle_map_decor")
	    ModManager.extendRoute("lib.battle.obj_list.terrain_list", "battle_terrain")
	    ModManager.extendRoute("lib.battle.obj_list.terrain_decor_list", "battle_terrain_decor")
	    ModManager.extendRoute("lib.battle.obj_list.faction_list", "battle_faction")
	    ModManager.extendRoute("lib.battle.obj_list.weapon_human_list", "battle_weapon")

	    ModManager.extendRoute("lib.battle.obj_list.unit_ally_list", "battle_unit_ally")
	    ModManager.extendRoute("lib.battle.obj_list.unit_bandit_list", "battle_unit_enemy")
	    
	    ModManager.extendRoute("lib.battle.obj_list.enemy_animal_list", "battle_enemy_set")
	    ModManager.extendRoute("lib.battle.obj_list.effect_list", "battle_effect")
	    ModManager.extendRoute("lib.battle.obj_list.perk_list", "battle_perk")
	    ModManager.extendRoute("lib.chest.item_chest_list", "item_chest")
	    ModManager.extendRoute("lib.chest.chest_list", "chest")
	    ModManager.extendRoute("lib.config.hard_config", "config_hard")
	    ModManager.extendRoute("lib.cooking_list", "cooking")
	    ModManager.extendRoute("lib.disease.disease_list", "disease")
	    ModManager.extendRoute("lib.interface.image_list", "image")
	    ModManager.extendRoute("lib.interface.image_sheet_list", "image_sheet")
	    ModManager.extendRoute("lib.items.ammo", "item")
	    ModManager.extendRoute("lib.level.recipe_list", "recipe")
	    ModManager.extendRoute("lib.level.perk_list", "perk")
	    ModManager.extendRoute("lib.level.level_list", "level")
	    ModManager.extendRoute("lib.location.city_list", "location_city")
	    ModManager.extendRoute("lib.location.location_list", "location")
	    -- ModManager.extendRoute("lib.location.location_season_list", "location")
	    ModManager.extendRoute("lib.location.base_npc", "location_base_npc")
	    ModManager.extendRoute("lib.location.base_enemy", "location_base_enemy")
	    ModManager.extendRoute("lib.loot.item_loot_list", "loot_item")
	    ModManager.extendRoute("lib.loot.miniloc_loot_list", "loot_miniloc")
	    ModManager.extendRoute("lib.loot.location_loot_list", "loot_location")
	    ModManager.extendRoute("lib.miniloc.miniloc_list", "miniloc")
	    ModManager.extendRoute("lib.npc.npc_list", "npc")
	    ModManager.extendRoute("lib.quest.bar_quest_list", "quest_bar")
	    ModManager.extendRoute("lib.quest.quest_list", "quest")
	    ModManager.extendRoute("lib.random_event_list", "random_event")
	    ModManager.extendRoute("lib.weather.weather_list", "weather")
	    
	    
	    ModManager.catroute() -- create category routing
	    
	    ModManager.extendFuncRoute("lib.interface.image_master", "image_method")
	    ModManager.extendFuncRoute("lib.battle.unit_logic", "battle_unit_logic")    
	        
	    -- =====================================    
	    local loader = require("angel_mod.loader")
	    
	    local allMods = loader.loadMods()
	    
	    local general = {
	        fontSize = {
	            title = 46,
	            body = 40,
	            footer = 34
	        },
	        button = {
	            close = {
	                size = 80,
	                height = 60
	            }
	        },
	        edgeRound = 8,
	    }
	    
	    -- Core util here 
	    
	    if #allMods.preload > 0 then        
	        loader.executeMods(allMods.preload, true)
	    else    
	        logToFile("ℹ️ No preload mods to load")
	    end
	    
	    if #allMods.normal > 0 then
	        -- Checker configuration
	        local checkInterval = 1000 -- milliseconds 
	        local maxAttempts = 40
	        local attempts = 0
	        local checkerTimer = nil
	        local labels = "main.gameNetwork"
	        
	        -- Self-destructing checker function
	        local function checkNotifications()
	    	    if checkerTimer then
			        timer.cancel(checkerTimer)
			        checkerTimer = nil
			    end

	            attempts = attempts + 1
	            
	            -- Success condition
	            if type(main) == "table" and type(main.gameNetwork) == "table" then
	                logToFile("✅ " .. labels .. " ready - Executing normal mods")
	                loader.executeMods(allMods.normal, false)
	                
	                itemlist = main.itemlist.table
	                bweapon = main.battle.weapon.table
	                
	                -- Clean up
	                if checkerTimer then timer.cancel(checkerTimer) end
	                checkNotifications = nil  -- Remove function reference
	                return
	            end
	            
	            -- Fail condition
	            if attempts >= maxAttempts then
	                logToFile("❌ Failed to find " .. labels .. " after "..maxAttempts.." attempts")
	                
	                -- Clean up
	                if checkerTimer then timer.cancel(checkerTimer) end
	                checkNotifications = nil
	                return
	            end
	            
	            -- Continue checking
	            logToFile("🔍 Waiting for " .. labels .. " (Attempt "..attempts.."/"..maxAttempts..")")
	            checkerTimer = timer.performWithDelay(checkInterval, checkNotifications)
	        end
	        
	        -- Start the checker
	        logToFile("⏳ Delaying "..#allMods.normal.." normal mods until " .. labels .. " exist...")
	        checkNotifications()  -- Initial call
	    else    
	        logToFile("ℹ️ No normal mods to load")
	    end
	    
	    logToFile("[CORE] finished")
	end 



	return core
