	return function()
	    safeRequire("reinternal.manager") -- ModManager (calls manager)
	    safeRequire("reinternal.utility") -- Global Utility (calls utility)
	    safeRequire("reinternal.lib") -- calls files, and init core
	end
